package com.cg.dao;

import com.cg.beans.Account;
import com.cg.beans.Loan;

public interface IBankDao {
	
	public int depositAmount(String accId,int amt);
	public int withdrawAmount(String accId,int amt);
	public Account showAccountDetails(String accountNo);
	public void createAccount(Account account);
	
	public int getLoan(String loanId,int lamt);
	public int payLoan(String loanId,int lamt);
	public Loan showLoanDetails(String loanId);
	
	
	
}
